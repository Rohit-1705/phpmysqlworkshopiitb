<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
    .container {
    height: 80vh;
    display: flex;
    justify-content: center;
    align-items: center;
    }
    button{
        height: 40px;
        width: 120px;
        margin: 10px;
    }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Student Result Storage System</h1>
    <div class="container">
    <a href="login.php"><button>Login</button></a>
    <a href="register.php"><button>Register</button></a>
    <a href="adminlogin.php"><button>Admin Login</button></a>
    </div>
</body>
</html>